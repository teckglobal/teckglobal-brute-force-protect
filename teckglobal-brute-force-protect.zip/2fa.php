<?php
if (!defined('ABSPATH')) {
    exit;
}

function teckglobal_bfp_generate_2fa_secret(): string {
    $g = new \Sonata\GoogleAuthenticator\GoogleAuthenticator();
    return $g->generateSecret();
}

function teckglobal_bfp_get_2fa_qr_code_url(string $secret, string $username): string {
    $g = new \Sonata\GoogleAuthenticator\GoogleAuthenticator();
    return \Sonata\GoogleAuthenticator\GoogleQrUrl::generate($username, $secret, 'TeckGlobal BFP');
}

function teckglobal_bfp_verify_2fa_code(int $user_id, string $code): bool {
    $secret = get_user_meta($user_id, 'teckglobal_bfp_2fa_secret', true);
    if (!$secret) {
        if (get_option('teckglobal_bfp_enable_debug_log', 0)) {
            error_log('TeckGlobal BFP 2FA Error: No secret found for user ID ' . $user_id);
        }
        return false;
    }
    $g = new \Sonata\GoogleAuthenticator\GoogleAuthenticator();
    $is_valid = $g->checkCode($secret, $code);
    if (get_option('teckglobal_bfp_enable_debug_log', 0)) {
        error_log('TeckGlobal BFP 2FA Verify: User ID ' . $user_id . ', Code: ' . $code . ', Secret: ' . $secret . ', Valid: ' . ($is_valid ? 'Yes' : 'No'));
    }
    return $is_valid;
}
