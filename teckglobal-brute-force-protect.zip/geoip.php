<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get IP location using MaxMind GeoLite2.
 */
function teckglobal_bfp_get_ip_location(string $ip): ?array {
    if (!file_exists(TECKGLOBAL_BFP_GEO_FILE)) {
        return null;
    }

    try {
        $reader = new \MaxMind\Db\Reader(TECKGLOBAL_BFP_GEO_FILE);
        $record = $reader->get($ip);
        $reader->close();

        if (!$record) {
            return null;
        }

        return [
            'country' => $record['country']['names']['en'] ?? 'Unknown',
            'latitude' => $record['location']['latitude'] ?? null,
            'longitude' => $record['location']['longitude'] ?? null
        ];
    } catch (Exception $e) {
        if (get_option('teckglobal_bfp_enable_debug_log', 0)) {
            error_log('TeckGlobal BFP GeoIP Error: ' . $e->getMessage());
        }
        return null;
    }
}

/**
 * Get the country of an IP.
 */
function teckglobal_bfp_get_ip_country(string $ip): ?string {
    $location = teckglobal_bfp_get_ip_location($ip);
    return $location['country'] ?? null;
}

/**
 * Get IP logs with pagination.
 */
function teckglobal_bfp_get_ip_logs(int $limit, int $page, bool $banned_only = false): array {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $offset = ($page - 1) * $limit;

    $where = $banned_only ? 'WHERE banned = 1' : '';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name $where ORDER BY timestamp DESC LIMIT %d OFFSET %d", $limit, $offset));

    return [
        'logs' => $logs,
        'pages' => ceil($total / $limit)
    ];
}

/**
 * Get a list of countries (simplified for this example).
 */
function teckglobal_bfp_get_countries(): array {
    return [
        'US' => 'United States',
        'CA' => 'Canada',
        'GB' => 'United Kingdom',
        'DE' => 'Germany',
        'FR' => 'France',
        'CN' => 'China',
        'RU' => 'Russia',
    ];
}
