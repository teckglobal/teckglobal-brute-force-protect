<?php
/**
 * Plugin Name: TeckGlobal Brute Force Protect
 * Plugin URI: https://teck-global.com/
 * Description: Protects WordPress from brute force attacks, scans, and more with advanced security features.
 * Version: 1.2.0
 * Author: TeckGlobal
 * Author URI: https://teck-global.com/
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: teckglobal-brute-force-protect
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TECKGLOBAL_BFP_URL', plugin_dir_url(__FILE__));
define('TECKGLOBAL_BFP_VERSION', '1.2.0'); // Match the version in the plugin header
define('TECKGLOBAL_BFP_PATH', plugin_dir_path(__FILE__)); // Optional, but useful for file paths

// Include dependencies
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

// Include all split files
$includes = [
    'core.php',
    '2fa.php',
    'security.php',
    'logs.php',
    'geoip.php',
    'setup.php',
    'admin.php',
    'login.php',
    'protection.php',
    'ajax.php'
];

foreach ($includes as $file) {
    require_once __DIR__ . '/includes/' . $file;
}

// Register hooks
register_activation_hook(__FILE__, 'teckglobal_bfp_activate');
register_deactivation_hook(__FILE__, 'teckglobal_bfp_deactivate');
register_uninstall_hook(__FILE__, 'teckglobal_bfp_uninstall');
