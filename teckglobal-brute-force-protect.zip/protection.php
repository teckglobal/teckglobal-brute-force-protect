<?php
if (!defined('ABSPATH')) {
    exit;
}

// Block Access Based on Country (Pro Feature)
add_action('init', 'teckglobal_bfp_block_countries');
function teckglobal_bfp_block_countries(): void {
    if (!teckglobal_bfp_is_pro() || !get_option('teckglobal_bfp_blocked_countries', [])) {
        return;
    }
    $ip = teckglobal_bfp_get_client_ip();
    $country = teckglobal_bfp_get_ip_country($ip);
    $blocked_countries = get_option('teckglobal_bfp_blocked_countries', []);
    if ($country && in_array($country, $blocked_countries)) {
        wp_die(
            esc_html__('Access from your country is blocked.', 'teckglobal-brute-force-protect'),
            esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
            ['response' => 403]
        );
    }
}

// Threat Feed Check
add_action('init', 'teckglobal_bfp_check_threat_feeds');
function teckglobal_bfp_check_threat_feeds(): void {
    if (!teckglobal_bfp_is_pro() || !get_option('teckglobal_bfp_threat_feeds', ['abuseipdb' => 0, 'project_honeypot' => 0])) {
        return;
    }
    $ip = teckglobal_bfp_get_client_ip();
    if (teckglobal_bfp_check_threat_feed($ip)) {
        teckglobal_bfp_ban_ip($ip, 'threat_feed');
        if (get_option('teckglobal_bfp_notify_on_threat', 0)) {
            $email = get_option('teckglobal_bfp_notification_email', get_option('admin_email'));
            $subject = __('Threat Feed Hit', 'teckglobal-brute-force-protect');
            $message = sprintf(__('IP %s was blocked due to a threat feed match.', 'teckglobal-brute-force-protect'), $ip);
            wp_mail($email, $subject, $message);
        }
        wp_die(
            esc_html__('Your IP is listed in a threat feed and has been blocked.', 'teckglobal-brute-force-protect'),
            esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
            ['response' => 403]
        );
    }
}

// WAF Protection
add_action('init', 'teckglobal_bfp_waf_protection');
function teckglobal_bfp_waf_protection(): void {
    if (!teckglobal_bfp_is_pro()) {
        return;
    }
    $ip = teckglobal_bfp_get_client_ip();
    $rules = teckglobal_bfp_get_waf_rules();
    $uri = esc_url_raw($_SERVER['REQUEST_URI'] ?? '');
    $user_agent = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''));

    foreach ($rules as $rule) {
        if (!$rule->enabled) {
            continue;
        }
        $pattern = $rule->pattern;
        $check_value = $rule->rule_type === 'uri' ? $uri : $user_agent;
        if (preg_match($pattern, $check_value)) {
            if ($rule->action === 'block') {
                teckglobal_bfp_ban_ip($ip, 'waf_rule');
                wp_die(
                    esc_html__('Suspicious request detected by WAF. Your IP has been blocked.', 'teckglobal-brute-force-protect'),
                    esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
                    ['response' => 403]
                );
            } else {
                teckglobal_bfp_log_attempt($ip); // Log only
            }
        }
    }
}

// Exploit Protection
add_action('init', 'teckglobal_bfp_exploit_protection');
function teckglobal_bfp_exploit_protection(): void {
    if (!get_option('teckglobal_bfp_exploit_protection', 0)) {
        return;
    }
    $ip = teckglobal_bfp_get_client_ip();
    $uri = esc_url_raw($_SERVER['REQUEST_URI'] ?? '');
    $sensitive_endpoints = ['wp-login.php', 'xmlrpc.php', 'wp-config.php'];
    $suspicious_patterns = ['/(\.\.\/|\/\.\.)/', '/(SELECT|UNION|INSERT|UPDATE|DELETE|DROP)/i', '/(<script|onload|onerror)/i'];

    foreach ($sensitive_endpoints as $endpoint) {
        if (strpos($uri, $endpoint) !== false) {
            teckglobal_bfp_log_attempt($ip);
            if (teckglobal_bfp_get_attempts_left($ip) <= 0) {
                teckglobal_bfp_ban_ip($ip, 'scan_exploit');
                wp_die(
                    esc_html__('Suspicious request detected. Your IP has been blocked.', 'teckglobal-brute-force-protect'),
                    esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
                    ['response' => 403]
                );
            }
            break;
        }
    }

    foreach ($suspicious_patterns as $pattern) {
        if (preg_match($pattern, $uri)) {
            teckglobal_bfp_ban_ip($ip, 'scan_exploit');
            wp_die(
                esc_html__('Suspicious request detected. Your IP has been blocked.', 'teckglobal-brute-force-protect'),
                esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
                ['response' => 403]
            );
            break;
        }
    }
}

// Security Headers (Pro Feature)
add_action('send_headers', 'teckglobal_bfp_add_security_headers');
function teckglobal_bfp_add_security_headers(): void {
    if (!teckglobal_bfp_is_pro()) {
        return;
    }
    $headers = get_option('teckglobal_bfp_security_headers', []);
    if (in_array('csp', $headers)) {
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';");
    }
    if (in_array('xfo', $headers)) {
        header('X-Frame-Options: DENY');
    }
    if (in_array('xss', $headers)) {
        header('X-XSS-Protection: 1; mode=block');
    }
}

// Scheduled Events
add_action('teckglobal_bfp_update_geoip', 'teckglobal_bfp_download_geoip');
add_action('teckglobal_bfp_malware_scan', 'teckglobal_bfp_run_malware_scan');

// Live Traffic Logging
add_action('wp', 'teckglobal_bfp_log_traffic');
function teckglobal_bfp_log_traffic(): void {
    if (teckglobal_bfp_is_pro()) {
        teckglobal_bfp_log_live_traffic(teckglobal_bfp_get_client_ip());
    }
}

// User Activity Logging
add_action('wp_login', 'teckglobal_bfp_log_user_login', 10, 2);
function teckglobal_bfp_log_user_login($user_login, $user): void {
    if (teckglobal_bfp_is_pro()) {
        teckglobal_bfp_log_user_activity($user->ID, 'login', teckglobal_bfp_get_client_ip());
    }
}

add_action('profile_update', 'teckglobal_bfp_log_profile_update', 10, 2);
function teckglobal_bfp_log_profile_update($user_id, $old_user_data): void {
    if (teckglobal_bfp_is_pro()) {
        teckglobal_bfp_log_user_activity($user_id, 'profile_update', teckglobal_bfp_get_client_ip());
    }
}
