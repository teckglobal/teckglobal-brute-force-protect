<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if the Pro version is active.
 */
function teckglobal_bfp_is_pro(): bool {
    $license_key = get_option('teckglobal_bfp_license_key', '');
    if (empty($license_key)) {
        return false;
    }
    // Hardcoded test keys for now (replace with real ones as you sell)
    $valid_keys = [
        'TG-BFP-TEST-1234-5678', // Test key for you
        'TG-BFP-0001-ABCD-EFGH'  // Example sold key
    ];
    return in_array($license_key, $valid_keys);
}

/**
 * Get the client's IP address.
 */
function teckglobal_bfp_get_client_ip(): string {
    $ip = '';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_CLIENT_IP']));
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR']));
    } else {
        $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
    }
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'unknown';
}

/**
 * Check if an IP is banned.
 */
function teckglobal_bfp_is_ip_banned(string $ip): bool {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';

    $whitelist_ips = array_filter(array_map('trim', explode("\n", get_option('teckglobal_bfp_whitelist_ips', ''))));
    if (in_array($ip, $whitelist_ips)) {
        error_log("TeckGlobal BFP: IP $ip is whitelisted, not banned.");
        return false;
    }

    $excluded_ips = get_option('teckglobal_bfp_excluded_ips', []);
    foreach ($excluded_ips as $excluded) {
        if (teckglobal_bfp_ip_in_range($ip, $excluded['ip'])) {
            error_log("TeckGlobal BFP: IP $ip is excluded via " . $excluded['ip'] . ", not banned.");
            return false;
        }
    }

    $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE ip = %s", $ip));
    if (!$log || !$log->banned) {
        return false;
    }

    if ($log->ban_expiry && current_time('mysql') > $log->ban_expiry) {
        teckglobal_bfp_unban_ip($ip);
        error_log("TeckGlobal BFP: IP $ip ban expired, unbanned.");
        return false;
    }

    error_log("TeckGlobal BFP: IP $ip is banned until " . $log->ban_expiry);
    return true;
}

/**
 * Ban an IP address.
 */
function teckglobal_bfp_ban_ip(string $ip, string $reason = 'brute_force'): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';

    $ban_time = get_option('teckglobal_bfp_ban_time', '60-minutes');
    $minutes = (int) str_replace('-minutes', '', $ban_time);
    $ban_expiry = date('Y-m-d H:i:s', strtotime(current_time('mysql') . " + $minutes minutes"));

    $data = [
        'ip' => $ip,
        'timestamp' => current_time('mysql'),
        'attempts' => 0,
        'banned' => 1,
        'ban_expiry' => $ban_expiry,
        'user_agent' => sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'))
    ];

    if ($reason === 'scan_exploit') {
        $data['scan_exploit'] = 1;
    } elseif ($reason === 'brute_force') {
        $data['brute_force'] = 1;
    } elseif ($reason === 'manual_ban') {
        $data['manual_ban'] = 1;
    }

    $geo_data = teckglobal_bfp_get_ip_location($ip);
    if ($geo_data) {
        $data['country'] = $geo_data['country'];
        $data['latitude'] = $geo_data['latitude'];
        $data['longitude'] = $geo_data['longitude'];
    }

    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE ip = %s", $ip));
    if ($existing) {
        $wpdb->update($table_name, $data, ['ip' => $ip]);
    } else {
        $wpdb->insert($table_name, $data);
    }

    if (get_option('teckglobal_bfp_enable_notifications', 0) && get_option('teckglobal_bfp_notify_on_ban', 1)) {
        $email = get_option('teckglobal_bfp_notification_email', get_option('admin_email'));
        $subject = __('IP Banned', 'teckglobal-brute-force-protect');
        $message = sprintf(__('IP %s was banned due to %s.', 'teckglobal-brute-force-protect'), $ip, $reason);
        wp_mail($email, $subject, $message);
    }
}

/**
 * Unban an IP address.
 */
function teckglobal_bfp_unban_ip(string $ip): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $wpdb->update($table_name, ['banned' => 0, 'ban_expiry' => null], ['ip' => $ip]);
}

/**
 * Log a failed attempt for an IP.
 */
function teckglobal_bfp_log_attempt(string $ip): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';

    if (!get_option('teckglobal_bfp_enable_logging', 1)) {
        return;
    }

    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE ip = %s", $ip));
    if ($existing) {
        $wpdb->update(
            $table_name,
            [
                'attempts' => $existing->attempts + 1,
                'timestamp' => current_time('mysql'),
                'user_agent' => sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'))
            ],
            ['ip' => $ip]
        );
    } else {
        $data = [
            'ip' => $ip,
            'timestamp' => current_time('mysql'),
            'attempts' => 1,
            'banned' => 0,
            'user_agent' => sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'))
        ];
        $geo_data = teckglobal_bfp_get_ip_location($ip);
        if ($geo_data) {
            $data['country'] = $geo_data['country'];
            $data['latitude'] = $geo_data['latitude'];
            $data['longitude'] = $geo_data['longitude'];
        }
        $wpdb->insert($table_name, $data);
    }
}

/**
 * Get the number of attempts left before an IP is banned.
 */
function teckglobal_bfp_get_attempts_left(string $ip): int {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $max_attempts = get_option('teckglobal_bfp_max_attempts', 5);
    if (get_option('teckglobal_bfp_exploit_protection', 0)) {
        $max_attempts = min($max_attempts, (int) get_option('teckglobal_bfp_exploit_max_attempts', 5));
    }

    $log = $wpdb->get_row($wpdb->prepare("SELECT attempts FROM $table_name WHERE ip = %s", $ip));
    return $log ? max(0, $max_attempts - (int) $log->attempts) : $max_attempts;
}

/**
 * Check if an IP is in a given range (supports CIDR).
 */
function teckglobal_bfp_ip_in_range(string $ip, string $range): bool {
    if (strpos($range, '/') === false) {
        return $ip === $range;
    }

    list($subnet, $bits) = explode('/', $range);
    $ip = ip2long($ip);
    $subnet = ip2long($subnet);
    $mask = -1 << (32 - $bits);
    $subnet &= $mask;
    return ($ip & $mask) === $subnet;
}
