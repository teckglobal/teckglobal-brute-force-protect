<?php
if (!defined('ABSPATH')) {
    exit;
}

// Admin Menu
add_action('admin_menu', 'teckglobal_bfp_admin_menu');
function teckglobal_bfp_admin_menu(): void {
    add_menu_page(
        __('Brute Force Protect', 'teckglobal-brute-force-protect'),
        __('Brute Force Protect', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-settings',
        'teckglobal_bfp_settings_page',
        'dashicons-shield'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('Settings', 'teckglobal-brute-force-protect'),
        __('Settings', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-settings',
        'teckglobal_bfp_settings_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('Manage IPs', 'teckglobal-brute-force-protect'),
        __('Manage IPs', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-manage-ips',
        'teckglobal_bfp_manage_ips_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('IP Logs & Map', 'teckglobal-brute-force-protect'),
        __('IP Logs & Map', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-ip-logs',
        'teckglobal_bfp_ip_logs_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('File Permissions', 'teckglobal-brute-force-protect'),
        __('File Permissions', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-file-permissions',
        'teckglobal_bfp_file_permissions_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('Live Traffic', 'teckglobal-brute-force-protect'),
        __('Live Traffic', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-live-traffic',
        'teckglobal_bfp_live_traffic_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('User Activity', 'teckglobal-brute-force-protect'),
        __('User Activity', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-user-activity',
        'teckglobal_bfp_user_activity_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('Malware Scanner', 'teckglobal-brute-force-protect'),
        __('Malware Scanner', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-malware-scanner',
        'teckglobal_bfp_malware_scanner_page'
    );
    add_submenu_page(
        'teckglobal-bfp-settings',
        __('WAF Rules', 'teckglobal-brute-force-protect'),
        __('WAF Rules', 'teckglobal-brute-force-protect'),
        'manage_options',
        'teckglobal-bfp-waf-rules',
        'teckglobal_bfp_waf_rules_page'
    );
}

// Enqueue Admin Assets
add_action('admin_enqueue_scripts', 'teckglobal_bfp_enqueue_admin_assets');
function teckglobal_bfp_enqueue_admin_assets($hook): void {
    if (strpos($hook, 'teckglobal-bfp') === false && $hook !== 'plugins.php' && $hook !== 'index.php') {
        return;
    }

    // Debug URL
    error_log('TECKGLOBAL_BFP_URL: ' . TECKGLOBAL_BFP_URL);

    wp_enqueue_style('teckglobal-bfp-style', TECKGLOBAL_BFP_URL . 'assets/css/style.css', [], TECKGLOBAL_BFP_VERSION);
    wp_enqueue_script('jquery');

    $script_handle = 'teckglobal-bfp-script';
    wp_enqueue_script($script_handle, TECKGLOBAL_BFP_URL . 'assets/js/script.js', ['jquery'], TECKGLOBAL_BFP_VERSION, true);

    $localize_data = [
        'ajax_url' => esc_url_raw(admin_url('admin-ajax.php')),
        'unban_nonce' => wp_create_nonce('teckglobal_bfp_unban_nonce'),
        'captcha_enabled' => (int) get_option('teckglobal_bfp_enable_captcha', 0),
        'captcha_site_key' => esc_attr(get_option('teckglobal_bfp_recaptcha_site_key', '')),
        'ip' => teckglobal_bfp_get_client_ip(),
        'is_banned' => teckglobal_bfp_is_ip_banned(teckglobal_bfp_get_client_ip()),
        'show_banned_only' => (int) get_option('teckglobal_bfp_show_banned_only', 0),
        'is_pro' => teckglobal_bfp_is_pro() ? 1 : 0
    ];

    if ($hook === 'brute-force-protect_page_teckglobal-bfp-ip-logs') {
        wp_enqueue_style('leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], '1.9.4');
        wp_enqueue_script('leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], '1.9.4', true);

        $limit = (int) get_option('teckglobal_bfp_ip_logs_per_page', 10);
        $banned_only = (bool) get_option('teckglobal_bfp_show_banned_only', 0);
        $logs_data = teckglobal_bfp_get_ip_logs($limit, 1, $banned_only);
        $logs = $logs_data['logs'];

        $locations = array_map(function($log) {
            return [
                'ip' => esc_js($log->ip),
                'lat' => floatval($log->latitude),
                'lng' => floatval($log->longitude),
                'country' => esc_js($log->country),
                'user_agent' => esc_js($log->user_agent ?? 'Unknown'),
                'banned' => (int) $log->banned
            ];
        }, $logs);

        $localize_data['locations'] = $locations;
    }

    if ($hook === 'brute-force-protect_page_teckglobal-bfp-live-traffic') {
        $localize_data['refresh_interval'] = 5000; // Refresh every 5 seconds
    }

    wp_localize_script($script_handle, 'teckglobal_bfp_ajax', $localize_data);
}

// Settings Page
function teckglobal_bfp_settings_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }

    $notice = '';
    if (isset($_POST['teckglobal_bfp_settings']) && check_admin_referer('teckglobal_bfp_settings')) {
        update_option('teckglobal_bfp_max_attempts', absint(wp_unslash($_POST['max_attempts'] ?? 5)));
        update_option('teckglobal_bfp_ban_time', sanitize_text_field(wp_unslash($_POST['ban_time'] ?? '60-minutes')));
        update_option('teckglobal_bfp_auto_ban_invalid', isset($_POST['auto_ban_invalid']) ? 1 : 0);
        update_option('teckglobal_bfp_exploit_protection', isset($_POST['exploit_protection']) ? 1 : 0);
        update_option('teckglobal_bfp_exploit_max_attempts', absint(wp_unslash($_POST['exp

loit_max_attempts'] ?? 5)));
        update_option('teckglobal_bfp_maxmind_key', sanitize_text_field(wp_unslash($_POST['maxmind_key'] ?? '')));
        update_option('teckglobal_bfp_remove_data', isset($_POST['remove_data']) ? 1 : 0);
        update_option('teckglobal_bfp_enable_logging', isset($_POST['enable_logging']) ? 1 : 0);
        update_option('teckglobal_bfp_block_message', sanitize_text_field(wp_unslash($_POST['block_message'] ?? 'Your IP has been blocked due to suspicious activity.')));
        update_option('teckglobal_bfp_enable_debug_log', isset($_POST['enable_debug_log']) ? 1 : 0);
        update_option('teckglobal_bfp_whitelist_ips', sanitize_textarea_field(wp_unslash($_POST['whitelist_ips'] ?? '')));
        update_option('teckglobal_bfp_enable_notifications', isset($_POST['enable_notifications']) ? 1 : 0);
        update_option('teckglobal_bfp_notification_email', sanitize_email(wp_unslash($_POST['notification_email'] ?? get_option('admin_email'))));
        update_option('teckglobal_bfp_notify_on_ban', isset($_POST['notify_on_ban']) ? 1 : 0);
        update_option('teckglobal_bfp_notify_on_attempts', isset($_POST['notify_on_attempts']) ? 1 : 0);
        update_option('teckglobal_bfp_notify_on_threat', isset($_POST['notify_on_threat']) ? 1 : 0);
        update_option('teckglobal_bfp_enable_captcha', isset($_POST['enable_captcha']) ? 1 : 0);
        update_option('teckglobal_bfp_recaptcha_site_key', sanitize_text_field(wp_unslash($_POST['recaptcha_site_key'] ?? '')));
        update_option('teckglobal_bfp_recaptcha_secret_key', sanitize_text_field(wp_unslash($_POST['recaptcha_secret_key'] ?? '')));
        update_option('teckglobal_bfp_enable_rate_limit', isset($_POST['enable_rate_limit']) ? 1 : 0);
        update_option('teckglobal_bfp_rate_limit_attempts', absint(wp_unslash($_POST['rate_limit_attempts'] ?? 3)));
        update_option('teckglobal_bfp_rate_limit_interval', absint(wp_unslash($_POST['rate_limit_interval'] ?? 60)));
        update_option('teckglobal_bfp_threat_feeds', array_map('boolval', wp_unslash($_POST['threat_feeds'] ?? ['abuseipdb' => 0, 'project_honeypot' => 0])));
        update_option('teckglobal_bfp_abuseipdb_key', sanitize_text_field(wp_unslash($_POST['abuseipdb_key'] ?? '')));
        update_option('teckglobal_bfp_project_honeypot_key', sanitize_text_field(wp_unslash($_POST['project_honeypot_key'] ?? '')));
        update_option('teckglobal_bfp_manage_ips_per_page', absint(wp_unslash($_POST['manage_ips_per_page'] ?? 10)));
        update_option('teckglobal_bfp_ip_logs_per_page', absint(wp_unslash($_POST['ip_logs_per_page'] ?? 10)));
        update_option('teckglobal_bfp_show_banned_only', isset($_POST['show_banned_only']) ? 1 : 0);
        update_option('teckglobal_bfp_login_banner_message', sanitize_text_field(wp_unslash($_POST['login_banner_message'] ?? 'Please login securely.')));
        update_option('teckglobal_bfp_license_key', sanitize_text_field(wp_unslash($_POST['license_key'] ?? '')));
        if (teckglobal_bfp_is_pro()) {
            update_option('teckglobal_bfp_blocked_countries', array_map('sanitize_text_field', wp_unslash($_POST['blocked_countries'] ?? [])));
            update_option('teckglobal_bfp_enable_2fa', isset($_POST['enable_2fa']) ? 1 : 0);
            update_option('teckglobal_bfp_password_policy', isset($_POST['password_policy']) ? 1 : 0);
            update_option('teckglobal_bfp_min_password_length', absint(wp_unslash($_POST['min_password_length'] ?? 8)));
            update_option('teckglobal_bfp_require_special_chars', isset($_POST['require_special_chars']) ? 1 : 0);
            update_option('teckglobal_bfp_security_headers', array_map('sanitize_text_field', wp_unslash($_POST['security_headers'] ?? [])));
            update_option('teckglobal_bfp_abuseipdb_confidence_score', absint(wp_unslash($_POST['abuseipdb_confidence_score'] ?? 75)));
        }

        $excluded_ips = [];
        if (isset($_POST['excluded_ip']) && is_array($_POST['excluded_ip'])) {
            foreach (wp_unslash($_POST['excluded_ip']) as $index => $ip) {
                $sanitized_ip = sanitize_text_field($ip);
                if (filter_var($sanitized_ip, FILTER_VALIDATE_IP) || preg_match('/^\d+\.\d+\.\d+\.\d+\/\d+$/', $sanitized_ip)) {
                    $excluded_ips[] = [
                        'ip' => $sanitized_ip,
                        'note' => sanitize_text_field(wp_unslash($_POST['excluded_note'][$index] ?? ''))
                    ];
                }
            }
        }
        update_option('teckglobal_bfp_excluded_ips', $excluded_ips);

        $notice = '<div class="updated"><p>' . esc_html__('Settings saved.', 'teckglobal-brute-force-protect') . '</p></div>';
    }

    if (isset($_POST['teckglobal_bfp_export']) && check_admin_referer('teckglobal_bfp_export')) {
        teckglobal_bfp_export_settings();
    }
    if (isset($_POST['teckglobal_bfp_import']) && check_admin_referer('teckglobal_bfp_import')) {
        teckglobal_bfp_import_settings();
    }

    add_action('admin_init', function() {
        if (current_user_can('manage_options') && isset($_GET['test_geoip_download']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'teckglobal_bfp_test_geoip')) {
            teckglobal_bfp_download_geoip();
            wp_redirect(admin_url('admin.php?page=teckglobal-bfp-ip-logs'));
            exit;
        }
    });

    $threat_feeds = get_option('teckglobal_bfp_threat_feeds', ['abuseipdb' => 0, 'project_honeypot' => 0]);
    $blocked_countries = get_option('teckglobal_bfp_blocked_countries', []);
    $security_headers = get_option('teckglobal_bfp_security_headers', []);
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <?php echo wp_kses_post($notice); ?>
        <h1><?php esc_html_e('Brute Force Protect Settings', 'teckglobal-brute-force-protect'); ?></h1>
        <form method="post">
            <?php wp_nonce_field('teckglobal_bfp_settings'); ?>

            <!-- Brute Force Protection Section -->
            <div class="settings-section brute-force-section">
                <h2><?php esc_html_e('Brute Force Protection', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Configure settings to protect against repeated login attempts.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Max Login Attempts', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="number" name="max_attempts" value="<?php echo esc_attr(get_option('teckglobal_bfp_max_attempts', 5)); ?>" min="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Ban Time', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <select name="ban_time">
                                <?php
                                $ban_time = get_option('teckglobal_bfp_ban_time', '60-minutes');
                                $options = ['15-minutes' => '15 Minutes', '60-minutes' => '1 Hour', '1440-minutes' => '24 Hours'];
                                foreach ($options as $value => $label) {
                                    printf('<option value="%s"%s>%s</option>', esc_attr($value), $ban_time === $value ? ' selected' : '', esc_html($label));
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Auto Ban Invalid Users', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="auto_ban_invalid" <?php checked(get_option('teckglobal_bfp_auto_ban_invalid', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Enable Rate Limiting', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="enable_rate_limit" <?php checked(get_option('teckglobal_bfp_enable_rate_limit', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Rate Limit Attempts', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="number" name="rate_limit_attempts" value="<?php echo esc_attr(get_option('teckglobal_bfp_rate_limit_attempts', 3)); ?>" min="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Rate Limit Interval (seconds)', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="number" name="rate_limit_interval" value="<?php echo esc_attr(get_option('teckglobal_bfp_rate_limit_interval', 60)); ?>" min="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Enable CAPTCHA', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="enable_captcha" <?php checked(get_option('teckglobal_bfp_enable_captcha', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('reCAPTCHA Site Key', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="recaptcha_site_key" value="<?php echo esc_attr(get_option('teckglobal_bfp_recaptcha_site_key', '')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('reCAPTCHA Secret Key', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="recaptcha_secret_key" value="<?php echo esc_attr(get_option('teckglobal_bfp_recaptcha_secret_key', '')); ?>" class="regular-text"></td>
                    </tr>
                    <?php if (teckglobal_bfp_is_pro()): ?>
                        <tr>
                            <th><?php esc_html_e('Enable Two-Factor Authentication (2FA)', 'teckglobal-brute-force-protect'); ?></th>
                            <td><input type="checkbox" name="enable_2fa" <?php checked(get_option('teckglobal_bfp_enable_2fa', 0)); ?> value="1"></td>
                        </tr>
                    <?php endif; ?>
                </table>
                <p><?php printf(esc_html__('Add Google reCAPTCHA v2 to block bots. Get keys %s.', 'teckglobal-brute-force-protect'), '<a href="https://www.google.com/recaptcha" target="_blank">here</a>'); ?></p>
            </div>

            <!-- Exploit Protection Section -->
            <div class="settings-section exploit-section">
                <h2><?php esc_html_e('Exploit Protection', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Block attempts to exploit vulnerabilities like SQL injection or XSS.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Enable Exploit Protection', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="exploit_protection" <?php checked(get_option('teckglobal_bfp_exploit_protection', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Max Exploit Attempts', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="number" name="exploit_max_attempts" value="<?php echo esc_attr(get_option('teckglobal_bfp_exploit_max_attempts', 5)); ?>" min="1"></td>
                    </tr>
                </table>
            </div>

            <!-- Geolocation & Mapping Section -->
            <div class="settings-section geo-section">
                <h2><?php esc_html_e('Geolocation & Mapping', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Track IP locations on a map using MaxMind GeoLite2.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('MaxMind License Key', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="maxmind_key" value="<?php echo esc_attr(get_option('teckglobal_bfp_maxmind_key', '')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('IP Logs Per Page', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <select name="ip_logs_per_page">
                                <?php
                                $per_page = get_option('teckglobal_bfp_ip_logs_per_page', 10);
                                for ($i = 10; $i <= 100; $i += 10) {
                                    printf('<option value="%d"%s>%d</option>', $i, $per_page == $i ? ' selected' : '', $i);
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Show Only Banned IPs on Map', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="show_banned_only" <?php checked(get_option('teckglobal_bfp_show_banned_only', 0)); ?> value="1"></td>
                    </tr>
                    <?php if (teckglobal_bfp_is_pro()): ?>
                        <tr>
                            <th><?php esc_html_e('Blocked Countries', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <select name="blocked_countries[]" multiple size="5">
                                    <?php
                                    $countries = teckglobal_bfp_get_countries();
                                    foreach ($countries as $code => $name) {
                                        printf('<option value="%s"%s>%s</option>', esc_attr($code), in_array($code, $blocked_countries) ? ' selected' : '', esc_html($name));
                                    }
                                    ?>
                                </select>
                                <p><?php esc_html_e('Select countries to block. Hold Ctrl/Cmd to select multiple.', 'teckglobal-brute-force-protect'); ?></p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </table>
                <p><?php printf(esc_html__('Get a free MaxMind key %s for geolocation.', 'teckglobal-brute-force-protect'), '<a href="https://www.maxmind.com/en/geolite2/signup" target="_blank">here</a>'); ?></p>
            </div>

            <!-- Threat Intelligence Section -->
            <div class="settings-section threat-section">
                <h2><?php esc_html_e('Threat Intelligence', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Block known malicious IPs using external threat feeds.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <?php if (teckglobal_bfp_is_pro()): ?>
                        <tr>
                            <th><?php esc_html_e('Threat Feeds', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <label><input type="checkbox" name="threat_feeds[abuseipdb]" <?php checked($threat_feeds['abuseipdb'] ?? 0); ?> value="1"> <?php esc_html_e('AbuseIPDB', 'teckglobal-brute-force-protect'); ?></label><br>
                                <label><input type="checkbox" name="threat_feeds[project_honeypot]" <?php checked($threat_feeds['project_honeypot'] ?? 0); ?> value="1"> <?php esc_html_e('Project Honeypot', 'teckglobal-brute-force-protect'); ?></label>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('AbuseIPDB API Key', 'teckglobal-brute-force-protect'); ?></th>
                            <td><input type="text" name="abuseipdb_key" value="<?php echo esc_attr(get_option('teckglobal_bfp_abuseipdb_key', '')); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('AbuseIPDB Confidence Score', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <input type="number" name="abuseipdb_confidence_score" value="<?php echo esc_attr(get_option('teckglobal_bfp_abuseipdb_confidence_score', 75)); ?>" min="0" max="100">
                                <p><?php esc_html_e('Set the minimum confidence score (0-100) to block IPs. Higher values reduce false positives.', 'teckglobal-brute-force-protect'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Project Honeypot API Key', 'teckglobal-brute-force-protect'); ?></th>
                            <td><input type="text" name="project_honeypot_key" value="<?php echo esc_attr(get_option('teckglobal_bfp_project_honeypot_key', '')); ?>" class="regular-text"></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <th><?php esc_html_e('Threat Feeds', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <p><?php esc_html_e('Threat feed integration (AbuseIPDB, Project Honeypot) is a Pro feature. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?></p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </table>
                <?php if (teckglobal_bfp_is_pro()): ?>
                    <p><?php printf(esc_html__('Get AbuseIPDB key %s and Project Honeypot key %s.', 'teckglobal-brute-force-protect'), '<a href="https://www.abuseipdb.com/register" target="_blank">here</a>', '<a href="https://www.projecthoneypot.org/httpbl_configure.php" target="_blank">here</a>'); ?></p>
                <?php endif; ?>
            </div>

            <!-- Notifications Section -->
            <div class="settings-section notification-section">
                <h2><?php esc_html_e('Notifications', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Receive email alerts for security events.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Enable Notifications', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="enable_notifications" <?php checked(get_option('teckglobal_bfp_enable_notifications', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Notification Email', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="email" name="notification_email" value="<?php echo esc_attr(get_option('teckglobal_bfp_notification_email', get_option('admin_email'))); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Notify On', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <label><input type="checkbox" name="notify_on_ban" <?php checked(get_option('teckglobal_bfp_notify_on_ban', 1)); ?> value="1"> <?php esc_html_e('IP Banned', 'teckglobal-brute-force-protect'); ?></label><br>
                            <?php if (teckglobal_bfp_is_pro()): ?>
                                <label><input type="checkbox" name="notify_on_attempts" <?php checked(get_option('teckglobal_bfp_notify_on_attempts', 0)); ?> value="1"> <?php esc_html_e('Attempts Warning', 'teckglobal-brute-force-protect'); ?></label><br>
                                <label><input type="checkbox" name="notify_on_threat" <?php checked(get_option('teckglobal_bfp_notify_on_threat', 0)); ?> value="1"> <?php esc_html_e('Threat Feed Hit', 'teckglobal-brute-force-protect'); ?></label>
                            <?php else: ?>
                                <p><?php esc_html_e('Advanced notifications (Attempts Warning, Threat Feed Hit) are Pro features. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Security Enhancements Section (Pro) -->
            <?php if (teckglobal_bfp_is_pro()): ?>
                <div class="settings-section security-section">
                    <h2><?php esc_html_e('Security Enhancements', 'teckglobal-brute-force-protect'); ?></h2>
                    <p><?php esc_html_e('Enhance your site’s security with additional features.', 'teckglobal-brute-force-protect'); ?></p>
                    <table class="form-table">
                        <tr>
                            <th><?php esc_html_e('Password Policy', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <label><input type="checkbox" name="password_policy" <?php checked(get_option('teckglobal_bfp_password_policy', 0)); ?> value="1"> <?php esc_html_e('Enforce Password Policy', 'teckglobal-brute-force-protect'); ?></label>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Minimum Password Length', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <input type="number" name="min_password_length" value="<?php echo esc_attr(get_option('teckglobal_bfp_min_password_length', 8)); ?>" min="1">
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Require Special Characters', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <input type="checkbox" name="require_special_chars" <?php checked(get_option('teckglobal_bfp_require_special_chars', 0)); ?> value="1">
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Security Headers', 'teckglobal-brute-force-protect'); ?></th>
                            <td>
                                <label><input type="checkbox" name="security_headers[csp]" <?php checked(in_array('csp', $security_headers)); ?> value="csp"> <?php esc_html_e('Content-Security-Policy', 'teckglobal-brute-force-protect'); ?></label><br>
                                <label><input type="checkbox" name="security_headers[xfo]" <?php checked(in_array('xfo', $security_headers)); ?> value="xfo"> <?php esc_html_e('X-Frame-Options', 'teckglobal-brute-force-protect'); ?></label><br>
                                <label><input type="checkbox" name="security_headers[xss]" <?php checked(in_array('xss', $security_headers)); ?> value="xss"> <?php esc_html_e('X-XSS-Protection', 'teckglobal-brute-force-protect'); ?></label>
                            </td>
                        </tr>
                    </table>
                </div>
            <?php endif; ?>

            <!-- Debugging Section -->
            <div class="settings-section debug-section">
                <h2><?php esc_html_e('Debugging', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Manage logs, messages, and cleanup options.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Enable Logging', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="enable_logging" <?php checked(get_option('teckglobal_bfp_enable_logging', 1)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Enable Debug Log', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="enable_debug_log" <?php checked(get_option('teckglobal_bfp_enable_debug_log', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Block Message', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="block_message" value="<?php echo esc_attr(get_option('teckglobal_bfp_block_message', 'Your IP has been blocked due to suspicious activity.')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Login Banner Message', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="login_banner_message" value="<?php echo esc_attr(get_option('teckglobal_bfp_login_banner_message', 'Please login securely.')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Remove Data on Uninstall', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="remove_data" <?php checked(get_option('teckglobal_bfp_remove_data', 0)); ?> value="1"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('License Key (Pro Version)', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <input type="text" name="license_key" value="<?php echo esc_attr(get_option('teckglobal_bfp_license_key', '')); ?>" class="regular-text">
                            <?php if (!teckglobal_bfp_is_pro()): ?>
                                <p><a href="https://teck-global.com/upgrade" target="_blank"><?php esc_html_e('Upgrade to Pro for advanced features!', 'teckglobal-brute-force-protect'); ?></a></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- IP Management Section -->
            <div class="settings-section ip-section">
                <h2><?php esc_html_e('IP Management', 'teckglobal-brute-force-protect'); ?></h2>
                <p><?php esc_html_e('Control which IPs are exempt or tracked.', 'teckglobal-brute-force-protect'); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Excluded IPs', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <table id="excluded-ips-table">
                                <thead><tr><th><?php esc_html_e('IP/CIDR', 'teckglobal-brute-force-protect'); ?></th><th><?php esc_html_e('Note', 'teckglobal-brute-force-protect'); ?></th><th></th></tr></thead>
                                <tbody id="excluded-ips-rows">
                                    <?php
                                    $excluded_ips = get_option('teckglobal_bfp_excluded_ips', []);
                                    foreach ($excluded_ips as $index => $entry) {
                                        printf(
                                            '<tr><td><input type="text" name="excluded_ip[]" value="%s"></td><td><input type="text" name="excluded_note[]" value="%s"></td><td><button type="button" class="button remove-row">%s</button></td></tr>',
                                            esc_attr($entry['ip']),
                                            esc_attr($entry['note']),
                                            esc_html__('Remove', 'teckglobal-brute-force-protect')
                                        );
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <p><button type="button" id="add-excluded-ip" class="button"><?php esc_html_e('Add IP', 'teckglobal-brute-force-protect'); ?></button></p>
                            <p><?php esc_html_e('Enter IPs or CIDR ranges (e.g., 192.168.1.0/24) to exclude from banning.', 'teckglobal-brute-force-protect'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('IP Whitelist', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <textarea name="whitelist_ips" rows="5" class="regular-text"><?php echo esc_textarea(get_option('teckglobal_bfp_whitelist_ips', '')); ?></textarea>
                            <p><?php esc_html_e('Enter one IP per line to whitelist from all checks.', 'teckglobal-brute-force-protect'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Manage IPs Per Page', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <select name="manage_ips_per_page">
                                <?php
                                $manage_per_page = get_option('teckglobal_bfp_manage_ips_per_page', 10);
                                for ($i = 10; $i <= 100; $i += 10) {
                                    printf('<option value="%d"%s>%d</option>', $i, $manage_per_page == $i ? ' selected' : '', $i);
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <p class="submit"><input type="submit" name="teckglobal_bfp_settings" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'teckglobal-brute-force-protect'); ?>"></p>
        </form>

        <!-- Export/Import Settings -->
        <div class="settings-section export-import-section">
            <h2><?php esc_html_e('Export/Import Settings', 'teckglobal-brute-force-protect'); ?></h2>
            <form method="post">
                <?php wp_nonce_field('teckglobal_bfp_export'); ?>
                <p><input type="submit" name="teckglobal_bfp_export" class="button" value="<?php esc_attr_e('Export Settings', 'teckglobal-brute-force-protect'); ?>"></p>
            </form>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('teckglobal_bfp_import'); ?>
                <p><input type="file" name="import_file" accept=".json"></p>
                <p><input type="submit" name="teckglobal_bfp_import" class="button" value="<?php esc_attr_e('Import Settings', 'teckglobal-brute-force-protect'); ?>"></p>
            </form>
        </div>
    </div>
    <?php
}

// Manage IPs Page
function teckglobal_bfp_manage_ips_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $per_page = (int) get_option('teckglobal_bfp_manage_ips_per_page', 10);
    $page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
    $offset = ($page - 1) * $per_page;

    if (isset($_POST['bulk_action']) && check_admin_referer('teckglobal_bfp_bulk_action')) {
        $action = sanitize_text_field(wp_unslash($_POST['bulk_action']));
        $ips = isset($_POST['ip']) ? array_map('sanitize_text_field', wp_unslash($_POST['ip'])) : [];
        foreach ($ips as $ip) {
            if ($action === 'ban') {
                teckglobal_bfp_ban_ip($ip, 'manual_ban');
            } elseif ($action === 'unban') {
                teckglobal_bfp_unban_ip($ip);
            } elseif ($action === 'delete') {
                $wpdb->delete($table_name, ['ip' => $ip]);
            }
        }
        echo '<div class="updated"><p>' . esc_html__('Bulk action completed.', 'teckglobal-brute-force-protect') . '</p></div>';
    }

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY timestamp DESC LIMIT %d OFFSET %d", $per_page, $offset));
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('Manage IPs', 'teckglobal-brute-force-protect'); ?></h1>
        <form method="post">
            <?php wp_nonce_field('teckglobal_bfp_bulk_action'); ?>
            <div class="tablenav top">
                <select name="bulk_action">
                    <option value=""><?php esc_html_e('Bulk Actions', 'teckglobal-brute-force-protect'); ?></option>
                    <option value="ban"><?php esc_html_e('Ban', 'teckglobal-brute-force-protect'); ?></option>
                    <option value="unban"><?php esc_html_e('Unban', 'teckglobal-brute-force-protect'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete', 'teckglobal-brute-force-protect'); ?></option>
                </select>
                <input type="submit" class="button" value="<?php esc_attr_e('Apply', 'teckglobal-brute-force-protect'); ?>">
            </div>
            <table class="wp-list-table widefat fixed striped teckglobal-log-table">
                <thead>
                    <tr>
                        <th class="check-column"><input type="checkbox"></th>
                        <th><?php esc_html_e('IP', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Attempts', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Banned', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Ban Expiry', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Country', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('User Agent', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Action', 'teckglobal-brute-force-protect'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($logs): ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td><input type="checkbox" name="ip[]" value="<?php echo esc_attr($log->ip); ?>"></td>
                                <td><?php echo esc_html($log->ip); ?></td>
                                <td><?php echo esc_html($log->attempts); ?></td>
                                <td><?php echo $log->banned ? esc_html__('Yes', 'teckglobal-brute-force-protect') : esc_html__('No', 'teckglobal-brute-force-protect'); ?></td>
                                <td><?php echo esc_html($log->ban_expiry ?? '-'); ?></td>
                                <td><?php echo esc_html($log->country ?? 'Unknown'); ?></td>
                                <td><?php echo esc_html($log->user_agent ?? 'Unknown'); ?></td>
                                <td>
                                    <?php if ($log->banned): ?>
                                        <a href="#" class="teckglobal-unban-ip ajax-unban" data-ip="<?php echo esc_attr($log->ip); ?>"><?php esc_html_e('Unban', 'teckglobal-brute-force-protect'); ?></a>
                                    <?php else: ?>
                                        <a href="#" class="teckglobal-ban-ip" data-ip="<?php echo esc_attr($log->ip); ?>"><?php esc_html_e('Ban', 'teckglobal-brute-force-protect'); ?></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8"><?php esc_html_e('No IPs logged.', 'teckglobal-brute-force-protect'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="tablenav bottom">
                <?php
                $total_pages = ceil($total / $per_page);
                echo paginate_links([
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => esc_html__('« Previous', 'teckglobal-brute-force-protect'),
                    'next_text' => esc_html__('Next »', 'teckglobal-brute-force-protect'),
                    'total' => $total_pages,
                    'current' => $page
                ]);
                ?>
            </div>
        </form>
    </div>
    <?php
}

// IP Logs & Map Page
function teckglobal_bfp_ip_logs_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    $maxmind_key = get_option('teckglobal_bfp_maxmind_key', '');
    $last_download = get_option('teckglobal_bfp_last_geoip_download', 'Never');
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('IP Logs & Map', 'teckglobal-brute-force-protect'); ?></h1>
        <?php if (!$maxmind_key): ?>
            <div class="notice notice-warning"><p><?php printf(esc_html__('MaxMind License Key is not set. Geolocation features will not work. Set it in the %s.', 'teckglobal-brute-force-protect'), '<a href="' . esc_url(admin_url('admin.php?page=teckglobal-bfp-settings')) . '">' . esc_html__('Settings', 'teckglobal-brute-force-protect') . '</a>'); ?></p></div>
        <?php elseif (!file_exists(TECKGLOBAL_BFP_GEO_FILE)): ?>
            <div class="notice notice-warning"><p><?php printf(esc_html__('GeoIP database is not downloaded. %s to enable geolocation.', 'teckglobal-brute-force-protect'), '<a href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=teckglobal-bfp-ip-logs&test_geoip_download=1'), 'teckglobal_bfp_test_geoip')) . '">' . esc_html__('Download now', 'teckglobal-brute-force-protect') . '</a>'); ?></p></div>
        <?php else: ?>
            <p><?php printf(esc_html__('GeoIP database last updated: %s', 'teckglobal-brute-force-protect'), esc_html($last_download)); ?></p>
        <?php endif; ?>
        <p><label><input type="checkbox" id="show-banned-only" <?php checked(get_option('teckglobal_bfp_show_banned_only', 0)); ?>> <?php esc_html_e('Show only banned IPs', 'teckglobal-brute-force-protect'); ?></label></p>
        <div id="bfp-map" style="height: 400px;"></div>
        <?php teckglobal_bfp_manage_ips_page(); ?>
    </div>
    <?php
}

// File Permissions Page
function teckglobal_bfp_file_permissions_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    $issues = teckglobal_bfp_scan_file_permissions();
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('File Permissions', 'teckglobal-brute-force-protect'); ?></h1>
        <?php if (empty($issues)): ?>
            <p><?php esc_html_e('No permission issues found.', 'teckglobal-brute-force-protect'); ?></p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped teckglobal-log-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('File', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Current Permissions', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Recommended Permissions', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Owner/Group', 'teckglobal-brute-force-protect'); ?></th>
                        <?php if (teckglobal_bfp_is_pro()): ?>
                            <th><?php esc_html_e('Action', 'teckglobal-brute-force-protect'); ?></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($issues as $issue): ?>
                        <tr>
                            <td><?php echo esc_html($issue['path']); ?></td>
                            <td><?php echo esc_html($issue['current_perms']); ?></td>
                            <td><?php echo esc_html($issue['recommended_perms']); ?></td>
                            <td><?php echo esc_html($issue['owner_group']); ?></td>
                            <?php if (teckglobal_bfp_is_pro()): ?>
                                <td><a href="#" class="teckglobal-fix-perms" data-file="<?php echo esc_attr($issue['path']); ?>" data-perms="<?php echo esc_attr($issue['recommended_perms']); ?>"><?php esc_html_e('Fix', 'teckglobal-brute-force-protect'); ?></a></td>
                            <?php else: ?>
                                <td><?php esc_html_e('Fixing permissions is a Pro feature. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}

// Live Traffic Page
function teckglobal_bfp_live_traffic_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    $logs = teckglobal_bfp_get_live_traffic(50);
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('Live Traffic', 'teckglobal-brute-force-protect'); ?></h1>
        <?php if (!teckglobal_bfp_is_pro()): ?>
            <p><?php esc_html_e('Live traffic monitoring is a Pro feature. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?> <a href="https://teck-global.com/upgrade" target="_blank"><?php esc_html_e('Upgrade to Pro', 'teckglobal-brute-force-protect'); ?></a></p>
        <?php elseif (empty($logs)): ?>
            <p><?php esc_html_e('No traffic data available.', 'teckglobal-brute-force-protect'); ?></p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped teckglobal-log-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('IP', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Timestamp', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('URL', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Method', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('User Agent', 'teckglobal-brute-force-protect'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->ip); ?></td>
                            <td><?php echo esc_html($log->timestamp); ?></td>
                            <td><?php echo esc_html($log->url); ?></td>
                            <td><?php echo esc_html($log->method); ?></td>
                            <td><?php echo esc_html($log->user_agent ?? 'Unknown'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}

// User Activity Page
function teckglobal_bfp_user_activity_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    $per_page = 10;
    $page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
    $data = teckglobal_bfp_get_user_activity($per_page, $page);
    $logs = $data['logs'];
    $total_pages = $data['pages'];
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('User Activity', 'teckglobal-brute-force-protect'); ?></h1>
        <?php if (!teckglobal_bfp_is_pro()): ?>
            <p><?php esc_html_e('User activity monitoring is a Pro feature. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?> <a href="https://teck-global.com/upgrade" target="_blank"><?php esc_html_e('Upgrade to Pro', 'teckglobal-brute-force-protect'); ?></a></p>
        <?php elseif (empty($logs)): ?>
            <p><?php esc_html_e('No user activity logs available.', 'teckglobal-brute-force-protect'); ?></p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped teckglobal-log-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('User', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Action', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Timestamp', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('IP', 'teckglobal-brute-force-protect'); ?></th>
                        <th><?php esc_html_e('Details', 'teckglobal-brute-force-protect'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo $log->user_id ? esc_html(get_userdata($log->user_id)->user_login) : esc_html__('Unknown', 'teckglobal-brute-force-protect'); ?></td>
                            <td><?php echo esc_html($log->action); ?></td>
                            <td><?php echo esc_html($log->timestamp); ?></td>
                            <td><?php echo esc_html($log->ip); ?></td>
                            <td><?php echo esc_html($log->details ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="tablenav bottom">
                <?php
                echo paginate_links([
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => esc_html__('« Previous', 'teckglobal-brute-force-protect'),
                    'next_text' => esc_html__('Next »', 'teckglobal-brute-force-protect'),
                    'total' => $total_pages,
                    'current' => $page
                ]);
                ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

// Malware Scanner Page
function teckglobal_bfp_malware_scanner_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    $scan_results = get_option('teckglobal_bfp_last_malware_scan', ['issues' => [], 'timestamp' => 'Never']);
    if (isset($_POST['run_scan']) && check_admin_referer('teckglobal_bfp_run_scan')) {
        $scan_results = teckglobal_bfp_run_malware_scan();
        update_option('teckglobal_bfp_last_malware_scan', $scan_results);
        echo '<div class="updated"><p>' . esc_html__('Malware scan completed.', 'teckglobal-brute-force-protect') . '</p></div>';
    }
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('Malware Scanner', 'teckglobal-brute-force-protect'); ?></h1>
        <?php if (!teckglobal_bfp_is_pro()): ?>
            <p><?php esc_html_e('Malware scanning is a Pro feature. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?> <a href="https://teck-global.com/upgrade" target="_blank"><?php esc_html_e('Upgrade to Pro', 'teckglobal-brute-force-protect'); ?></a></p>
        <?php else: ?>
            <form method="post">
                <?php wp_nonce_field('teckglobal_bfp_run_scan'); ?>
                <p><input type="submit" name="run_scan" class="button button-primary" value="<?php esc_attr_e('Run Scan', 'teckglobal-brute-force-protect'); ?>"></p>
            </form>
            <p><?php printf(esc_html__('Last scan: %s', 'teckglobal-brute-force-protect'), esc_html($scan_results['timestamp'])); ?></p>
            <?php if (empty($scan_results['issues'])): ?>
                <p><?php esc_html_e('No issues found in the last scan.', 'teckglobal-brute-force-protect'); ?></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped teckglobal-log-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('File', 'teckglobal-brute-force-protect'); ?></th>
                            <th><?php esc_html_e('Issue', 'teckglobal-brute-force-protect'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($scan_results['issues'] as $issue): ?>
                            <tr>
                                <td><?php echo esc_html($issue['file']); ?></td>
                                <td><?php echo esc_html($issue['issue']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}

// WAF Rules Page
function teckglobal_bfp_waf_rules_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized access', 'teckglobal-brute-force-protect'));
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_waf_rules';

    if (isset($_POST['add_rule']) && check_admin_referer('teckglobal_bfp_add_rule')) {
        $pattern = sanitize_text_field(wp_unslash($_POST['pattern'] ?? ''));
        if (empty($pattern)) {
            echo '<div class="error"><p>' . esc_html__('Pattern cannot be empty.', 'teckglobal-brute-force-protect') . '</p></div>';
        } else {
            $wpdb->insert($table_name, [
                'rule_type' => sanitize_text_field(wp_unslash($_POST['rule_type'] ?? 'uri')),
                'pattern' => $pattern,
                'action' => sanitize_text_field(wp_unslash($_POST['action'] ?? 'block')),
                'description' => sanitize_text_field(wp_unslash($_POST['description'] ?? '')),
                'enabled' => isset($_POST['enabled']) ? 1 : 0
            ]);
            echo '<div class="updated"><p>' . esc_html__('Rule added successfully.', 'teckglobal-brute-force-protect') . '</p></div>';
        }
    }

    if (isset($_POST['update_rule']) && check_admin_referer('teckglobal_bfp_update_rule')) {
        $id = absint($_POST['rule_id']);
        $wpdb->update($table_name, [
            'rule_type' => sanitize_text_field(wp_unslash($_POST['rule_type'] ?? 'uri')),
            'pattern' => sanitize_text_field(wp_unslash($_POST['pattern'] ?? '')),
            'action' => sanitize_text_field(wp_unslash($_POST['action'] ?? 'block')),
            'description' => sanitize_text_field(wp_unslash($_POST['description'] ?? '')),
            'enabled' => isset($_POST['enabled']) ? 1 : 0
        ], ['id' => $id]);
        echo '<div class="updated"><p>' . esc_html__('Rule updated successfully.', 'teckglobal-brute-force-protect') . '</p></div>';
    }

    if (isset($_GET['delete']) && check_admin_referer('teckglobal_bfp_delete_rule')) {
        $id = absint($_GET['delete']);
        $wpdb->delete($table_name, ['id' => $id]);
        echo '<div class="updated"><p>' . esc_html__('Rule deleted successfully.', 'teckglobal-brute-force-protect') . '</p></div>';
    }

    $rules = teckglobal_bfp_get_waf_rules();
    ?>
    <div class="wrap teckglobal-bfp-wrap">
        <h1><?php esc_html_e('WAF Rules', 'teckglobal-brute-force-protect'); ?></h1>
        <?php if (!teckglobal_bfp_is_pro()): ?>
            <p><?php esc_html_e('Web Application Firewall (WAF) is a Pro feature. Upgrade to unlock!', 'teckglobal-brute-force-protect'); ?> <a href="https://teck-global.com/upgrade" target="_blank"><?php esc_html_e('Upgrade to Pro', 'teckglobal-brute-force-protect'); ?></a></p>
        <?php else: ?>
            <h2><?php esc_html_e('Add New Rule', 'teckglobal-brute-force-protect'); ?></h2>
            <form method="post">
                <?php wp_nonce_field('teckglobal_bfp_add_rule'); ?>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Rule Type', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <select name="rule_type">
                                <option value="uri"><?php esc_html_e('URI', 'teckglobal-brute-force-protect'); ?></option>
                                <option value="user_agent"><?php esc_html_e('User Agent', 'teckglobal-brute-force-protect'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Pattern', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="pattern" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Action', 'teckglobal-brute-force-protect'); ?></th>
                        <td>
                            <select name="action">
                                <option value="block"><?php esc_html_e('Block', 'teckglobal-brute-force-protect'); ?></option>
                                <option value="log"><?php esc_html_e('Log Only', 'teckglobal-brute-force-protect'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Description', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="text" name="description" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Enabled', 'teckglobal-brute-force-protect'); ?></th>
                        <td><input type="checkbox" name="enabled" value="1" checked></td>
                    </tr>
                </table>
                <p><input type="submit" name="add_rule" class="button button-primary" value="<?php esc_attr_e('Add Rule', 'teckglobal-brute-force-protect'); ?>"></p>
            </form>

            <h2><?php esc_html_e('Current Rules', 'teckglobal-brute-force-protect'); ?></h2>
            <?php if (empty($rules)): ?>
                <p><?php esc_html_e('No WAF rules found.', 'teckglobal-brute-force-protect'); ?></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped teckglobal-log-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Type', 'teckglobal-brute-force-protect'); ?></th>
                            <th><?php esc_html_e('Pattern', 'teckglobal-brute-force-protect'); ?></th>
                            <th><?php esc_html_e('Action', 'teckglobal-brute-force-protect'); ?></th>
                            <th><?php esc_html_e('Description', 'teckglobal-brute-force-protect'); ?></th>
                            <th><?php esc_html_e('Enabled', 'teckglobal-brute-force-protect'); ?></th>
                            <th><?php esc_html_e('Actions', 'teckglobal-brute-force-protect'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rules as $rule): ?>
                            <tr>
                                <td><?php echo esc_html($rule->rule_type); ?></td>
                                <td><?php echo esc_html($rule->pattern); ?></td>
                                <td><?php echo esc_html($rule->action); ?></td>
                                <td><?php echo esc_html($rule->description ?? '-'); ?></td>
                                <td><?php echo $rule->enabled ? esc_html__('Yes', 'teckglobal-brute-force-protect') : esc_html__('No', 'teckglobal-brute-force-protect'); ?></td>
                                <td>
                                    <a href="#" class="edit-rule" data-id="<?php echo esc_attr($rule->id); ?>" data-type="<?php echo esc_attr($rule->rule_type); ?>" data-pattern="<?php echo esc_attr($rule->pattern); ?>" data-action="<?php echo esc_attr($rule->action); ?>" data-description="<?php echo esc_attr($rule->description ?? ''); ?>" data-enabled="<?php echo esc_attr($rule->enabled); ?>"><?php esc_html_e('Edit', 'teckglobal-brute-force-protect'); ?></a> |
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=teckglobal-bfp-waf-rules&delete=' . $rule->id), 'teckglobal_bfp_delete_rule')); ?>" onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this rule?', 'teckglobal-brute-force-protect'); ?>');"><?php esc_html_e('Delete', 'teckglobal-brute-force-protect'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('.edit-rule').on('click', function(e) {
            e.preventDefault();
            var $this = $(this);
            var id = $this.data('id');
            var type = $this.data('type');
            var pattern = $this.data('pattern');
            var action = $this.data('action');
            var description = $this.data('description');
            var enabled = $this.data('enabled');

            var form = '<form method="post">' +
                '<?php wp_nonce_field('teckglobal_bfp_update_rule'); ?>' +
                '<input type="hidden" name="rule_id" value="' + id + '">' +
                '<table class="form-table">' +
                '<tr><th><?php esc_html_e('Rule Type', 'teckglobal-brute-force-protect'); ?></th><td><select name="rule_type"><option value="uri" ' + (type === 'uri' ? 'selected' : '') + '><?php esc_html_e('URI', 'teckglobal-brute-force-protect'); ?></option><option value="user_agent" ' + (type === 'user_agent' ? 'selected' : '') + '><?php esc_html_e('User Agent', 'teckglobal-brute-force-protect'); ?></option></select></td></tr>' +
                '<tr><th><?php esc_html_e('Pattern', 'teckglobal-brute-force-protect'); ?></th><td><input type="text" name="pattern" value="' + pattern + '" class="regular-text" required></td></tr>' +
                '<tr><th><?php esc_html_e('Action', 'teckglobal-brute-force-protect'); ?></th><td><select name="action"><option value="block" ' + (action === 'block' ? 'selected' : '') + '><?php esc_html_e('Block', 'teckglobal-brute-force-protect'); ?></option><option value="log" ' + (action === 'log' ? 'selected' : '') + '><?php esc_html_e('Log Only', 'teckglobal-brute-force-protect'); ?></option></select></td></tr>' +
                '<tr><th><?php esc_html_e('Description', 'teckglobal-brute-force-protect'); ?></th><td><input type="text" name="description" value="' + description + '" class="regular-text"></td></tr>' +
                '<tr><th><?php esc_html_e('Enabled', 'teckglobal-brute-force-protect'); ?></th><td><input type="checkbox" name="enabled" value="1" ' + (enabled ? 'checked' : '') + '></td></tr>' +
                '</table>' +
                '<p><input type="submit" name="update_rule" class="button button-primary" value="<?php esc_attr_e('Update Rule', 'teckglobal-brute-force-protect'); ?>"></p>' +
                '</form>';

            $this.closest('tr').replaceWith('<tr><td colspan="6">' + form + '</td></tr>');
        });
    });
    </script>
    <?php
}

// Dashboard Widget
add_action('wp_dashboard_setup', 'teckglobal_bfp_dashboard_widget');
function teckglobal_bfp_dashboard_widget(): void {
    wp_add_dashboard_widget(
        'teckglobal_bfp_widget',
        __('Brute Force Protect Stats', 'teckglobal-brute-force-protect'),
        'teckglobal_bfp_dashboard_widget_content'
    );
}

function teckglobal_bfp_dashboard_widget_content(): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $today = current_time('Y-m-d');
    $blocked_today = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE banned = 1 AND timestamp LIKE %s", "$today%"));
    $total_blocked = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE banned = 1");
    $recent = $wpdb->get_results($wpdb->prepare("SELECT ip, country, timestamp FROM $table_name WHERE banned = 1 ORDER BY timestamp DESC LIMIT 5"));
    ?>
    <p><?php printf(esc_html__('Blocked Today: %d', 'teckglobal-brute-force-protect'), esc_html($blocked_today)); ?></p>
    <p><?php printf(esc_html__('Total IPs Blocked: %d', 'teckglobal-brute-force-protect'), esc_html($total_blocked)); ?></p>
    <?php if ($recent): ?>
        <h4><?php esc_html_e('Recent Activity', 'teckglobal-brute-force-protect'); ?></h4>
        <ul>
            <?php foreach ($recent as $log): ?>
                <li><?php printf(esc_html__('IP %s (%s) blocked on %s', 'teckglobal-brute-force-protect'), esc_html($log->ip), esc_html($log->country ?? 'Unknown'), esc_html($log->timestamp)); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <p><a href="<?php echo esc_url(admin_url('admin.php?page=teckglobal-bfp-ip-logs')); ?>"><?php esc_html_e('View Logs & Map', 'teckglobal-brute-force-protect'); ?></a></p>
    <?php
}
