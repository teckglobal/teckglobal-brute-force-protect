<?php
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue Login Assets
add_action('login_enqueue_scripts', 'teckglobal_bfp_enqueue_login_assets');
function teckglobal_bfp_enqueue_login_assets(): void {
    if (get_option('teckglobal_bfp_enable_captcha', 0)) {
        wp_enqueue_script('teckglobal-bfp-recaptcha', 'https://www.google.com/recaptcha/api.js', [], null, false);
    }
    if (teckglobal_bfp_is_pro() && get_option('teckglobal_bfp_enable_2fa', 0)) {
        wp_enqueue_script('teckglobal-bfp-2fa', TECKGLOBAL_BFP_URL . 'assets/js/2fa.js', ['jquery'], TECKGLOBAL_BFP_VERSION, true);
        wp_localize_script('teckglobal-bfp-2fa', 'teckglobal_bfp_2fa', [
            'ajax_url' => esc_url_raw(admin_url('admin-ajax.php')),
            'nonce' => wp_create_nonce('teckglobal_bfp_2fa_nonce')
        ]);
    }
    wp_enqueue_style('teckglobal-bfp-style', TECKGLOBAL_BFP_URL . 'assets/css/style.css', [], TECKGLOBAL_BFP_VERSION);
    wp_enqueue_script('teckglobal-bfp-script', TECKGLOBAL_BFP_URL . 'assets/js/script.js', ['jquery'], TECKGLOBAL_BFP_VERSION, true);

    $ip = teckglobal_bfp_get_client_ip();
    wp_localize_script('teckglobal-bfp-script', 'teckglobal_bfp_ajax', [
        'ajax_url' => esc_url_raw(admin_url('admin-ajax.php')),
        'unban_nonce' => wp_create_nonce('teckglobal_bfp_unban_nonce'),
        'captcha_enabled' => (int) get_option('teckglobal_bfp_enable_captcha', 0),
        'captcha_site_key' => esc_attr(get_option('teckglobal_bfp_recaptcha_site_key', '')),
        'ip' => $ip,
        'is_banned' => teckglobal_bfp_is_ip_banned($ip),
        'banner_message' => esc_attr(get_option('teckglobal_bfp_login_banner_message', 'Please login securely.')),
        'attempts_left' => teckglobal_bfp_get_attempts_left($ip) // Added for script.js
    ]);
}

// Display Login Banner
add_action('login_message', 'teckglobal_bfp_display_login_banner');
function teckglobal_bfp_display_login_banner($message): string {
    $banner_message = get_option('teckglobal_bfp_login_banner_message', 'Please login securely.');
    if (!empty($banner_message)) {
        $message .= '<p class="message">' . esc_html($banner_message) . '</p>';
    }
    return $message;
}

// Display 2FA Field on Login
add_action('login_form', 'teckglobal_bfp_display_2fa_field');
function teckglobal_bfp_display_2fa_field(): void {
    if (!teckglobal_bfp_is_pro() || !get_option('teckglobal_bfp_enable_2fa', 0)) {
        return;
    }
    $user = isset($_POST['log']) ? get_user_by('login', sanitize_text_field(wp_unslash($_POST['log']))) : null;
    if ($user && get_user_meta($user->ID, 'teckglobal_bfp_2fa_enabled', true)) {
        ?>
        <p>
            <label for="teckglobal_bfp_2fa_code"><?php esc_html_e('2FA Code', 'teckglobal-brute-force-protect'); ?></label>
            <input type="text" name="teckglobal_bfp_2fa_code" id="teckglobal_bfp_2fa_code" class="input" value="" size="20">
        </p>
        <?php
    }
}

// Login Protection
add_action('wp_login_failed', 'teckglobal_bfp_log_failed_login');
function teckglobal_bfp_log_failed_login($username): void {
    $ip = teckglobal_bfp_get_client_ip();
    if (teckglobal_bfp_is_ip_banned($ip)) {
        return;
    }
    teckglobal_bfp_log_attempt($ip);
    $attempts_left = teckglobal_bfp_get_attempts_left($ip);

    if ($attempts_left <= 0 || (get_option('teckglobal_bfp_auto_ban_invalid', 0) && !username_exists($username))) {
        teckglobal_bfp_ban_ip($ip, 'brute_force');
    }

    if (teckglobal_bfp_is_pro() && get_option('teckglobal_bfp_notify_on_attempts', 0) && $attempts_left <= 2) {
        $email = get_option('teckglobal_bfp_notification_email', get_option('admin_email'));
        $subject = __('Login Attempts Warning', 'teckglobal-brute-force-protect');
        $message = sprintf(__('IP %s has %d login attempts left before being banned.', 'teckglobal-brute-force-protect'), $ip, $attempts_left);
        wp_mail($email, $subject, $message);
    }
}

add_filter('authenticate', 'teckglobal_bfp_check_login', 20, 3);
function teckglobal_bfp_check_login($user, $username, $password) {
    $ip = teckglobal_bfp_get_client_ip();

    if (teckglobal_bfp_is_ip_banned($ip)) {
        wp_die(
            esc_html(get_option('teckglobal_bfp_block_message', __('Too many login attempts. Your IP has been blocked.', 'teckglobal-brute-force-protect'))),
            esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
            ['response' => 403]
        );
    }

    // Only log attempt if username and password are provided but before 2FA check
    if (!empty($username) && !empty($password) && !username_exists($username)) {
        teckglobal_bfp_log_attempt($ip);
    }

    if (teckglobal_bfp_is_pro() && get_option('teckglobal_bfp_enable_2fa', 0) && $user instanceof WP_User && get_user_meta($user->ID, 'teckglobal_bfp_2fa_enabled', true)) {
        $code = sanitize_text_field(wp_unslash($_POST['teckglobal_bfp_2fa_code'] ?? ''));
        if (empty($code)) {
            return new WP_Error('2fa_required', __('Please enter your 2FA code.', 'teckglobal-brute-force-protect'));
        }
        if (!teckglobal_bfp_verify_2fa_code($user->ID, $code)) {
            return new WP_Error('invalid_2fa', __('Invalid 2FA code.', 'teckglobal-brute-force-protect'));
        }
    }

    if (teckglobal_bfp_is_pro() && get_option('teckglobal_bfp_password_policy', 0)) {
        $min_length = (int) get_option('teckglobal_bfp_min_password_length', 8);
        $require_special = (bool) get_option('teckglobal_bfp_require_special_chars', 0);
        if (strlen($password) < $min_length) {
            return new WP_Error('weak_password', sprintf(__('Password must be at least %d characters long.', 'teckglobal-brute-force-protect'), $min_length));
        }
        if ($require_special && !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
            return new WP_Error('weak_password', __('Password must contain at least one special character.', 'teckglobal-brute-force-protect'));
        }
    }

    return $user;
}

// Rate Limiting
add_action('wp_login_failed', 'teckglobal_bfp_rate_limit_check');
function teckglobal_bfp_rate_limit_check($username): void {
    $ip = teckglobal_bfp_get_client_ip();
    if (!teckglobal_bfp_check_rate_limit($ip)) {
        teckglobal_bfp_ban_ip($ip, 'rate_limit');
        wp_die(
            esc_html__('Too many login attempts. Your IP has been blocked.', 'teckglobal-brute-force-protect'),
            esc_html__('Access Denied', 'teckglobal-brute-force-protect'),
            ['response' => 403]
        );
    }
}

// 2FA User Profile Settings
add_action('show_user_profile', 'teckglobal_bfp_2fa_user_profile');
add_action('edit_user_profile', 'teckglobal_bfp_2fa_user_profile');
function teckglobal_bfp_2fa_user_profile($user): void {
    if (!teckglobal_bfp_is_pro() || !get_option('teckglobal_bfp_enable_2fa', 0)) {
        return;
    }
    $is_enabled = get_user_meta($user->ID, 'teckglobal_bfp_2fa_enabled', true);
    $secret = get_user_meta($user->ID, 'teckglobal_bfp_2fa_secret', true);
    if (!$secret) {
        $secret = teckglobal_bfp_generate_2fa_secret();
    }
    ?>
    <h3><?php esc_html_e('Two-Factor Authentication', 'teckglobal-brute-force-protect'); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="teckglobal_bfp_2fa_enabled"><?php esc_html_e('Enable 2FA', 'teckglobal-brute-force-protect'); ?></label></th>
            <td>
                <input type="checkbox" name="teckglobal_bfp_2fa_enabled" id="teckglobal_bfp_2fa_enabled" value="1" <?php checked($is_enabled); ?>>
            </td>
        </tr>
        <?php if (!$is_enabled): ?>
        <tr>
            <th><?php esc_html_e('Setup 2FA', 'teckglobal-brute-force-protect'); ?></th>
            <td>
                <p><?php esc_html_e('Scan this QR code with your authenticator app:', 'teckglobal-brute-force-protect'); ?></p>
                <img src="<?php echo esc_url(teckglobal_bfp_get_2fa_qr_code_url($secret, $user->user_login)); ?>" alt="2FA QR Code">
                <p><?php esc_html_e('Or enter this secret manually:', 'teckglobal-brute-force-protect'); ?></p>
                <input type="text" value="<?php echo esc_attr($secret); ?>" readonly class="regular-text">
            </td>
        </tr>
        <?php endif; ?>
    </table>
    <?php
}

add_action('personal_options_update', 'teckglobal_bfp_save_2fa_settings');
add_action('edit_user_profile_update', 'teckglobal_bfp_save_2fa_settings');
function teckglobal_bfp_save_2fa_settings($user_id): void {
    if (!teckglobal_bfp_is_pro() || !get_option('teckglobal_bfp_enable_2fa', 0) || !current_user_can('edit_user', $user_id)) {
        return;
    }
    $enabled = isset($_POST['teckglobal_bfp_2fa_enabled']) ? 1 : 0;
    $current_enabled = get_user_meta($user_id, 'teckglobal_bfp_2fa_enabled', true);
    if ($enabled && !$current_enabled) {
        $secret = teckglobal_bfp_generate_2fa_secret();
        update_user_meta($user_id, 'teckglobal_bfp_2fa_secret', $secret);
    }
    update_user_meta($user_id, 'teckglobal_bfp_2fa_enabled', $enabled);
}
