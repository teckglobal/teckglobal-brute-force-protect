<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Log live traffic (Pro feature).
 */
function teckglobal_bfp_log_live_traffic(string $ip): void {
    if (!teckglobal_bfp_is_pro()) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_live_traffic';
    $url = esc_url_raw($_SERVER['REQUEST_URI'] ?? '');
    $method = sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    $user_agent = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'));

    $wpdb->insert($table_name, [
        'ip' => $ip,
        'timestamp' => current_time('mysql'),
        'url' => $url,
        'method' => $method,
        'user_agent' => $user_agent
    ]);
}

/**
 * Get live traffic logs (Pro feature).
 */
function teckglobal_bfp_log_user_activity(int $user_id, string $action, string $ip, string $details = ''): void {
    if (!teckglobal_bfp_is_pro()) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_user_activity';
    $wpdb->insert($table_name, [
        'user_id' => $user_id,
        'action' => $action,
        'timestamp' => current_time('mysql'),
        'ip' => $ip,
        'details' => $details
    ]);
}

/**
 * Get user activity logs (Pro feature).
 */
function teckglobal_bfp_get_user_activity(int $limit, int $page): array {
    if (!teckglobal_bfp_is_pro()) {
        return ['logs' => [], 'pages' => 0];
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_user_activity';
    $offset = ($page - 1) * $limit;

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY timestamp DESC LIMIT %d OFFSET %d", $limit, $offset));

    return [
        'logs' => $logs,
        'pages' => ceil($total / $limit)
    ];
}

/**
 * Run a malware scan (Pro feature, simplified for this example).
 */
function teckglobal_bfp_run_malware_scan(): array {
    if (!teckglobal_bfp_is_pro()) {
        return ['issues' => []];
    }

    $issues = [];
    $patterns = [
        '/eval\(/i' => 'Potential eval() usage',
        '/base64_decode\(/i' => 'Potential base64_decode() usage',
        '/exec\(/i' => 'Potential exec() usage'
    ];

    $dirs = [ABSPATH . 'wp-content/plugins', ABSPATH . 'wp-content/themes'];
    foreach ($dirs as $dir) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $content = file_get_contents($file->getPathname());
                foreach ($patterns as $pattern => $desc) {
                    if (preg_match($pattern, $content)) {
                        $issues[] = [
                            'file' => str_replace(ABSPATH, '', $file->getPathname()),
                            'issue' => $desc
                        ];
                    }
                }
            }
        }
    }

    return ['issues' => $issues, 'timestamp' => current_time('mysql')];
}

/**
 * Scan file permissions.
 */
function teckglobal_bfp_scan_file_permissions(): array {
    $issues = [];
    $files_to_check = [
        ABSPATH . 'wp-config.php' => 0640,
        ABSPATH . '.htaccess' => 0644,
        ABSPATH . 'wp-content' => 0755,
        ABSPATH . 'wp-content/plugins' => 0755,
        ABSPATH . 'wp-content/themes' => 0755
    ];

    foreach ($files_to_check as $path => $recommended) {
        if (!file_exists($path)) {
            continue;
        }

        $perms = fileperms($path) & 0777;
        if ($perms !== $recommended) {
            $issues[] = [
                'path' => str_replace(ABSPATH, '', $path),
                'current_perms' => sprintf('%o', $perms),
                'recommended_perms' => sprintf('%o', $recommended),
                'owner_group' => function_exists('posix_getpwuid') ? posix_getpwuid(fileowner($path))['name'] . '/' . posix_getgrgid(filegroup($path))['name'] : 'Unknown'
            ];
        }
    }

    return $issues;
}

/**
 * Fix file permissions (Pro feature).
 */
function teckglobal_bfp_fix_file_permissions(string $file, int $perms): bool {
    if (!teckglobal_bfp_is_pro()) {
        return false;
    }

    $full_path = ABSPATH . ltrim($file, '/');
    return @chmod($full_path, octdec($perms));
}
