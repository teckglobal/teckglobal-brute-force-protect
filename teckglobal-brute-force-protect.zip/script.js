/**
 * TeckGlobal Brute Force Protect - Admin Script
 * Version: 1.1.2
 */
jQuery(document).ready(function($) {
    // Map initialization for IP logs page
    if ($('#bfp-map').length) {
        if (typeof L === 'undefined') {
            alert('Leaflet library failed to load. Please check your plugin setup.');
            return;
        }

        // Initialize or reset the map
        if (!window.bfpMap) {
            window.bfpMap = L.map('bfp-map').setView([0, 0], 2);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 18
            }).addTo(window.bfpMap);
        } else {
            window.bfpMap.eachLayer(function(layer) {
                if (layer instanceof L.Marker || layer instanceof L.LayerGroup) {
                    window.bfpMap.removeLayer(layer);
                }
            });
        }

        // Ensure teckglobal_bfp_ajax is defined and log its state
        if (typeof teckglobal_bfp_ajax === 'undefined') {
            console.error('teckglobal_bfp_ajax is not defined. Check wp_localize_script in PHP.');
            alert('Map data is unavailable due to a configuration error.');
            return;
        }

        var locationsData = teckglobal_bfp_ajax.locations || [];
        console.log('Locations data:', locationsData); // Debug log to verify data

        function updateMap(bannedOnly) {
            if (window.bfpMap) {
                window.bfpMap.eachLayer(function(layer) {
                    if (layer instanceof L.Marker || layer instanceof L.LayerGroup) {
                        window.bfpMap.removeLayer(layer);
                    }
                });
            }

            if (Array.isArray(locationsData) && locationsData.length > 0) {
                var markers = L.layerGroup().addTo(window.bfpMap);
                var bounds = [];

                locationsData.forEach(function(location) {
                    if (location.lat && location.lng && !isNaN(location.lat) && !isNaN(location.lng)) {
                        if (!bannedOnly || (bannedOnly && location.banned)) {
                            var marker = L.marker([location.lat, location.lng]).addTo(markers);
                            marker.bindPopup(
                                '<b>IP:</b> ' + (location.ip || 'Unknown') +
                                '<br><b>Country:</b> ' + (location.country || 'Unknown') +
                                '<br><b>User Agent:</b> ' + (location.user_agent || 'Unknown') +
                                '<br><b>Banned:</b> ' + (location.banned ? 'Yes' : 'No')
                            );
                            bounds.push([location.lat, location.lng]);
                        }
                    } else {
                        console.warn('Invalid location data:', location); // Log invalid entries
                    }
                });

                if (bounds.length > 0) {
                    window.bfpMap.fitBounds(bounds);
                } else {
                    console.log('No valid geolocation data to display for current filter.');
                    alert('No valid geolocation data available to display on the map with current filter.');
                }
            } else {
                console.log('No locations data available or empty array.');
                alert('No IP log data available to display on the map.');
            }
        }

        // Initial map render based on saved setting
        var showBannedOnly = teckglobal_bfp_ajax.show_banned_only === 1;
        updateMap(showBannedOnly);

        // Checkbox change handler
        $('#show-banned-only').on('change', function() {
            var isChecked = $(this).is(':checked');
            updateMap(isChecked);

            // Update setting via AJAX
            $.ajax({
                url: teckglobal_bfp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'teckglobal_bfp_update_show_banned',
                    nonce: teckglobal_bfp_ajax.unban_nonce,
                    show_banned_only: isChecked ? 1 : 0
                },
                success: function(response) {
                    if (!response.success) {
                        console.error('Failed to update show_banned_only setting:', response.data.message);
                    }
                },
                error: function() {
                    console.error('AJAX request failed to update show_banned_only setting.');
                }
            });
        });
    }

    // AJAX unban functionality
    $(document).on('click', '.teckglobal-unban-ip.ajax-unban', function(e) {
        e.preventDefault();
        var $button = $(this);
        var ip = $button.data('ip');

        if (!confirm('Are you sure you want to unban IP ' + ip + '?')) {
            return;
        }

        if (typeof teckglobal_bfp_ajax === 'undefined') {
            alert('AJAX configuration not found. Please contact support.');
            return;
        }

        $.ajax({
            url: teckglobal_bfp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'teckglobal_bfp_unban_ip',
                nonce: teckglobal_bfp_ajax.unban_nonce,
                ip: ip
            },
            success: function(response) {
                if (response.success) {
                    $button.replaceWith('<span>Unbanned</span>');
                    // Refresh map after unban
                    var showBannedOnly = $('#show-banned-only').is(':checked');
                    updateMap(showBannedOnly);
                } else {
                    alert('Failed to unban IP: ' + (response.data.message || 'Unknown error'));
                }
            },
            error: function() {
                alert('Failed to process unban request. Please try again.');
            }
        });
    });

    // Login form enhancements
    if ($('#loginform').length) {
        if (teckglobal_bfp_ajax.captcha_enabled) {
            $('#loginform p.submit').before(
                '<div class="g-recaptcha" data-sitekey="' + teckglobal_bfp_ajax.captcha_site_key + '"></div>'
            );
        }

        if (!teckglobal_bfp_ajax.is_banned && teckglobal_bfp_ajax.attempts_left < 5) {
            $('#loginform').prepend(
                '<p class="bfp-attempts-notice">Warning: ' + teckglobal_bfp_ajax.attempts_left +
                ' login attempts remaining before ban.</p>'
            );
        }

        $('#loginform').on('submit', function(e) {
            var $form = $(this);
            var isBanned = teckglobal_bfp_ajax.is_banned;

            if (isBanned) {
                e.preventDefault();
                $form.addClass('teckglobal-bfp-blocked');
                setTimeout(function() {
                    $form.removeClass('teckglobal-bfp-blocked');
                }, 1000);
            }
        });
    }

    // Dynamic excluded IPs table
    $('#add-excluded-ip').on('click', function() {
        $('#excluded-ips-rows').append(
            '<tr><td><input type="text" name="excluded_ip[]" value="" /></td>' +
            '<td><input type="text" name="excluded_note[]" value="" /></td>' +
            '<td><button type="button" class="button remove-row">Remove</button></td></tr>'
        );
    });

    $(document).on('click', '.remove-row', function() {
        $(this).closest('tr').remove();
    });
});
