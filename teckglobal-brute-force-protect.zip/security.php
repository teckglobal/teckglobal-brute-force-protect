<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check rate limiting for an IP.
 */
function teckglobal_bfp_check_rate_limit(string $ip): bool {
    if (!get_option('teckglobal_bfp_enable_rate_limit', 0)) {
        return true;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $rate_limit_attempts = (int) get_option('teckglobal_bfp_rate_limit_attempts', 3);
    $rate_limit_interval = (int) get_option('teckglobal_bfp_rate_limit_interval', 60);

    $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE ip = %s", $ip));
    if (!$log) {
        return true;
    }

    $time_diff = strtotime(current_time('mysql')) - strtotime($log->timestamp);
    if ($time_diff < $rate_limit_interval && $log->attempts >= $rate_limit_attempts) {
        return false;
    }

    if ($time_diff >= $rate_limit_interval) {
        $wpdb->update($table_name, ['attempts' => 0], ['ip' => $ip]);
    }

    return true;
}

/**
 * Get WAF rules.
 */
function teckglobal_bfp_get_waf_rules(): array {
    global $wpdb;
    $table_name = $wpdb->prefix . 'teckglobal_bfp_waf_rules';
    return $wpdb->get_results("SELECT * FROM $table_name");
}

/**
 * Check threat feeds (simplified for this example).
 */
function teckglobal_bfp_check_threat_feed(string $ip): bool {
    if (!teckglobal_bfp_is_pro()) {
        return false;
    }

    $threat_feeds = get_option('teckglobal_bfp_threat_feeds', ['abuseipdb' => 0, 'project_honeypot' => 0]);
    $abuseipdb_key = get_option('teckglobal_bfp_abuseipdb_key', '');
    $confidence_score = (int) get_option('teckglobal_bfp_abuseipdb_confidence_score', 75);

    if ($threat_feeds['abuseipdb'] && $abuseipdb_key) {
        $response = wp_remote_get("https://api.abuseipdb.com/api/v2/check?ipAddress=$ip&maxAgeInDays=90", [
            'headers' => ['Key' => $abuseipdb_key, 'Accept' => 'application/json']
        ]);

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($body['data']['abuseConfidenceScore']) && $body['data']['abuseConfidenceScore'] >= $confidence_score) {
                return true;
            }
        }
    }

    // Add Project Honeypot check if enabled
    return false;
}
