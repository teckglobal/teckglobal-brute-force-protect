<?php
if (!defined('ABSPATH')) {
    exit;
}

// AJAX Handlers
add_action('wp_ajax_teckglobal_bfp_unban_ip', 'teckglobal_bfp_ajax_unban_ip');
function teckglobal_bfp_ajax_unban_ip(): void {
    check_ajax_referer('teckglobal_bfp_unban_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Unauthorized access', 'teckglobal-brute-force-protect')]);
    }
    $ip = sanitize_text_field(wp_unslash($_POST['ip'] ?? ''));
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        wp_send_json_error(['message' => __('Invalid IP address.', 'teckglobal-brute-force-protect')]);
    }
    teckglobal_bfp_unban_ip($ip);
    wp_send_json_success(['message' => sprintf(__('IP %s has been unbanned.', 'teckglobal-brute-force-protect'), $ip)]);
}

add_action('wp_ajax_teckglobal_bfp_update_show_banned', 'teckglobal_bfp_ajax_update_show_banned');
function teckglobal_bfp_ajax_update_show_banned(): void {
    check_ajax_referer('teckglobal_bfp_unban_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Unauthorized access', 'teckglobal-brute-force-protect')]);
    }
    $show_banned_only = absint($_POST['show_banned_only'] ?? 0);
    update_option('teckglobal_bfp_show_banned_only', $show_banned_only);
    wp_send_json_success();
}

add_action('wp_ajax_teckglobal_bfp_validate_2fa', 'teckglobal_bfp_ajax_validate_2fa');
function teckglobal_bfp_ajax_validate_2fa(): void {
    check_ajax_referer('teckglobal_bfp_2fa_nonce', 'nonce');
    $code = sanitize_text_field(wp_unslash($_POST['code'] ?? ''));
    $user = wp_get_current_user();
    if (!$user->ID) {
        wp_send_json_error(['message' => __('No user logged in.', 'teckglobal-brute-force-protect')]);
    }
    $is_valid = teckglobal_bfp_verify_2fa_code($user->ID, $code);
    if (get_option('teckglobal_bfp_enable_debug_log', 0)) {
        error_log('TeckGlobal BFP 2FA Validation: User ID ' . $user->ID . ', Code: ' . $code . ', Valid: ' . ($is_valid ? 'Yes' : 'No'));
    }
    if (!$is_valid) {
        wp_send_json_error(['message' => __('Invalid 2FA code.', 'teckglobal-brute-force-protect')]);
    }
    wp_send_json_success();
}
