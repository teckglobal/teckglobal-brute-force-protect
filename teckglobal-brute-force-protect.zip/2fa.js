/**
 * TeckGlobal Brute Force Protect - 2FA Script
 * Version: 1.0.0
 */
jQuery(document).ready(function($) {
    // Handle 2FA code submission on login form
    if ($('#loginform').length && $('#teckglobal_bfp_2fa_code').length) {
        $('#loginform').on('submit', function(e) {
            e.preventDefault();
            var $form = $(this);
            var code = $('#teckglobal_bfp_2fa_code').val().trim();

            if (!code) {
                alert('Please enter your 2FA code.');
                return;
            }

            if (typeof teckglobal_bfp_2fa === 'undefined') {
                console.error('teckglobal_bfp_2fa is not defined. Check wp_localize_script in PHP.');
                alert('2FA configuration error. Please contact support.');
                return;
            }

            $.ajax({
                url: teckglobal_bfp_2fa.ajax_url,
                type: 'POST',
                data: {
                    action: 'teckglobal_bfp_validate_2fa',
                    nonce: teckglobal_bfp_2fa.nonce,
                    code: code
                },
                success: function(response) {
                    if (response.success) {
                        // 2FA valid, proceed with form submission
                        $form.off('submit').submit();
                    } else {
                        alert('Invalid 2FA code: ' + (response.data.message || 'Please try again.'));
                        $('#teckglobal_bfp_2fa_code').val('').focus();
                    }
                },
                error: function() {
                    alert('Failed to validate 2FA code. Please try again.');
                }
            });
        });
    }
});
