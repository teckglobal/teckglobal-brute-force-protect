<?php
if (!defined('ABSPATH')) {
    exit;
}

// Activation Hook
function teckglobal_bfp_activate(): void {
    teckglobal_bfp_install_tables();
    update_option('teckglobal_bfp_version', TECKGLOBAL_BFP_VERSION);

    if (!wp_next_scheduled('teckglobal_bfp_update_geoip')) {
        wp_schedule_event(time(), 'weekly', 'teckglobal_bfp_update_geoip');
    }
    if (!wp_next_scheduled('teckglobal_bfp_malware_scan')) {
        wp_schedule_event(time(), 'daily', 'teckglobal_bfp_malware_scan');
    }
}

// Deactivation Hook
function teckglobal_bfp_deactivate(): void {
    wp_clear_scheduled_hook('teckglobal_bfp_update_geoip');
    wp_clear_scheduled_hook('teckglobal_bfp_malware_scan');
}

// Uninstall Hook
function teckglobal_bfp_uninstall(): void {
    if (get_option('teckglobal_bfp_remove_data', 0)) {
        global $wpdb;
        $tables = [
            $wpdb->prefix . 'teckglobal_bfp_logs',
            $wpdb->prefix . 'teckglobal_bfp_waf_rules',
            $wpdb->prefix . 'teckglobal_bfp_live_traffic',
            $wpdb->prefix . 'teckglobal_bfp_user_activity'
        ];
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        delete_option('teckglobal_bfp_version');
        delete_option('teckglobal_bfp_max_attempts');
        delete_option('teckglobal_bfp_ban_time');
        delete_option('teckglobal_bfp_auto_ban_invalid');
        delete_option('teckglobal_bfp_exploit_protection');
        delete_option('teckglobal_bfp_exploit_max_attempts');
        delete_option('teckglobal_bfp_maxmind_key');
        delete_option('teckglobal_bfp_remove_data');
        delete_option('teckglobal_bfp_enable_logging');
        delete_option('teckglobal_bfp_block_message');
        delete_option('teckglobal_bfp_enable_debug_log');
        delete_option('teckglobal_bfp_whitelist_ips');
        delete_option('teckglobal_bfp_enable_notifications');
        delete_option('teckglobal_bfp_notification_email');
        delete_option('teckglobal_bfp_notify_on_ban');
        delete_option('teckglobal_bfp_notify_on_attempts');
        delete_option('teckglobal_bfp_notify_on_threat');
        delete_option('teckglobal_bfp_enable_captcha');
        delete_option('teckglobal_bfp_recaptcha_site_key');
        delete_option('teckglobal_bfp_recaptcha_secret_key');
        delete_option('teckglobal_bfp_enable_rate_limit');
        delete_option('teckglobal_bfp_rate_limit_attempts');
        delete_option('teckglobal_bfp_rate_limit_interval');
        delete_option('teckglobal_bfp_threat_feeds');
        delete_option('teckglobal_bfp_abuseipdb_key');
        delete_option('teckglobal_bfp_project_honeypot_key');
        delete_option('teckglobal_bfp_last_geoip_download');
        delete_option('teckglobal_bfp_show_banned_only');
        delete_option('teckglobal_bfp_ip_logs_per_page');
        delete_option('teckglobal_bfp_manage_ips_per_page');
        delete_option('teckglobal_bfp_login_banner_message');
        delete_option('teckglobal_bfp_excluded_ips');
        delete_option('teckglobal_bfp_license_key');
        delete_option('teckglobal_bfp_blocked_countries');
        delete_option('teckglobal_bfp_enable_2fa');
        delete_option('teckglobal_bfp_password_policy');
        delete_option('teckglobal_bfp_min_password_length');
        delete_option('teckglobal_bfp_require_special_chars');
        delete_option('teckglobal_bfp_security_headers');
        delete_option('teckglobal_bfp_abuseipdb_confidence_score');
        delete_option('teckglobal_bfp_last_malware_scan');

        if (file_exists(TECKGLOBAL_BFP_GEO_FILE)) {
            unlink(TECKGLOBAL_BFP_GEO_FILE);
        }
    }
}

// Install Tables
function teckglobal_bfp_install_tables(): void {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Check prefix length (MySQL limit: 64 chars, teckglobal_bfp_ = 13, longest suffix = 13)
    if (strlen($wpdb->prefix) > 38) {
        error_log('TeckGlobal BFP Error: Table prefix "' . $wpdb->prefix . '" exceeds 38 characters, risking table name truncation. Plugin tables not created.');
        return;
    }

    // Logs Table
    $table_name = $wpdb->prefix . 'teckglobal_bfp_logs';
    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ip VARCHAR(45) NOT NULL,
        attempts INT DEFAULT 0,
        banned TINYINT(1) DEFAULT 0,
        ban_expiry DATETIME DEFAULT NULL,
        timestamp DATETIME NOT NULL,
        latitude DECIMAL(10, 8) DEFAULT NULL,
        longitude DECIMAL(11, 8) DEFAULT NULL,
        country VARCHAR(100) DEFAULT NULL,
        user_agent TEXT DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY ip (ip)
    ) $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    // WAF Rules Table
    $waf_table = $wpdb->prefix . 'teckglobal_bfp_waf_rules';
    $sql = "CREATE TABLE $waf_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        rule_type VARCHAR(50) NOT NULL,
        pattern TEXT NOT NULL,
        action VARCHAR(50) NOT NULL,
        description TEXT DEFAULT NULL,
        enabled TINYINT(1) DEFAULT 1,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);

    // Live Traffic Table
    $traffic_table = $wpdb->prefix . 'teckglobal_bfp_live_traffic';
    $sql = "CREATE TABLE $traffic_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        ip VARCHAR(45) NOT NULL,
        timestamp DATETIME NOT NULL,
        url TEXT NOT NULL,
        method VARCHAR(10) NOT NULL,
        user_agent TEXT DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);

    // User Activity Table
    $activity_table = $wpdb->prefix . 'teckglobal_bfp_user_activity';
    $sql = "CREATE TABLE $activity_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        action VARCHAR(100) NOT NULL,
        timestamp DATETIME NOT NULL,
        ip VARCHAR(45) NOT NULL,
        details TEXT DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql);

    // Set version
    $installed_ver = get_option('teckglobal_bfp_version', '0');
    if (version_compare($installed_ver, TECKGLOBAL_BFP_VERSION, '<')) {
        update_option('teckglobal_bfp_version', TECKGLOBAL_BFP_VERSION);
    }
}

// Export Settings
function teckglobal_bfp_export_settings(): void {
    if (!current_user_can('manage_options')) {
        return;
    }
    $settings = [];
    $options = [
        'teckglobal_bfp_max_attempts',
        'teckglobal_bfp_ban_time',
        'teckglobal_bfp_auto_ban_invalid',
        'teckglobal_bfp_exploit_protection',
        'teckglobal_bfp_exploit_max_attempts',
        'teckglobal_bfp_maxmind_key',
        'teckglobal_bfp_remove_data',
        'teckglobal_bfp_enable_logging',
        'teckglobal_bfp_block_message',
        'teckglobal_bfp_enable_debug_log',
        'teckglobal_bfp_whitelist_ips',
        'teckglobal_bfp_enable_notifications',
        'teckglobal_bfp_notification_email',
        'teckglobal_bfp_notify_on_ban',
        'teckglobal_bfp_notify_on_attempts',
        'teckglobal_bfp_notify_on_threat',
        'teckglobal_bfp_enable_captcha',
        'teckglobal_bfp_recaptcha_site_key',
        'teckglobal_bfp_recaptcha_secret_key',
        'teckglobal_bfp_enable_rate_limit',
        'teckglobal_bfp_rate_limit_attempts',
        'teckglobal_bfp_rate_limit_interval',
        'teckglobal_bfp_threat_feeds',
        'teckglobal_bfp_abuseipdb_key',
        'teckglobal_bfp_project_honeypot_key',
        'teckglobal_bfp_show_banned_only',
        'teckglobal_bfp_ip_logs_per_page',
        'teckglobal_bfp_manage_ips_per_page',
        'teckglobal_bfp_login_banner_message',
        'teckglobal_bfp_excluded_ips',
        'teckglobal_bfp_license_key',
        'teckglobal_bfp_blocked_countries',
        'teckglobal_bfp_enable_2fa',
        'teckglobal_bfp_password_policy',
        'teckglobal_bfp_min_password_length',
        'teckglobal_bfp_require_special_chars',
        'teckglobal_bfp_security_headers',
        'teckglobal_bfp_abuseipdb_confidence_score'
    ];
    foreach ($options as $option) {
        $settings[$option] = get_option($option);
    }
    $json = json_encode($settings, JSON_PRETTY_PRINT);
    header('Content-Disposition: attachment; filename="teckglobal-bfp-settings.json"');
    header('Content-Type: application/json');
    echo $json;
    exit;
}

// Import Settings
function teckglobal_bfp_import_settings(): void {
    if (!current_user_can('manage_options') || !isset($_FILES['import_file'])) {
        return;
    }
    $file = $_FILES['import_file'];
    if ($file['type'] !== 'application/json' || $file['size'] > 1048576) { // 1MB limit
        add_settings_error('teckglobal_bfp_settings', 'import_error', __('Invalid file format or size exceeded.', 'teckglobal-brute-force-protect'));
        return;
    }
    $json = file_get_contents($file['tmp_name']);
    $settings = json_decode($json, true);
    if (!is_array($settings)) {
        add_settings_error('teckglobal_bfp_settings', 'import_error', __('Invalid JSON data.', 'teckglobal-brute-force-protect'));
        return;
    }
    foreach ($settings as $option => $value) {
        update_option($option, $value);
    }
    add_settings_error('teckglobal_bfp_settings', 'import_success', __('Settings imported successfully.', 'teckglobal-brute-force-protect'), 'updated');
}
